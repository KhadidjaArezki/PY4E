# Using-Python-to-access-web-data
Assignment python programs on the Coursera course "Using Python to access web data"
